Be sure to add -XY argument while using ssh to get into tux.
Matplotlib requires that there is X-window support.
 
To run the script, simply use the following command, 
  ./main.py

This script uses the KMEAN.py script, that contains all the computational information for the k-mean calculations. Dataset of diabetes.csv is provided. 

For all k-mean clustering related computation, please look into KMEAN.py. There are comments in them to help in understanding my process. 

The main.py script runs a sample of the object and plots the desired visualizations that are mentioned in the assignment requirement. 
