To run the script, simply use the following command, 
  
  ./main.py

This script uses the pca.py script, that contains all the computational information for the PCA calculations. Dataset of diabetes.csv is provided. 

For all PCA related computation, please look into pca.py. There are comments in them to help in understanding my process. 

The main.py script generates an output.svg file, which is the visualization of the projected data. To view the file, simply open it using any browser. 
