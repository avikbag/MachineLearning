To run the script, simply use the following command, 
  
  python -W ignore main.py

All the source information for the computation of SVM and multi SVM is available in SupportVectorMachine.py and MultiSupportVectorMachine.py respectively.
