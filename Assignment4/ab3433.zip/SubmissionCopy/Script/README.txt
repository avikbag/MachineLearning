To run the script, simply use the following command, 
  
  python -W ignore main.py

All the source information for the computation of gradient descent is available in GradientDescent.py