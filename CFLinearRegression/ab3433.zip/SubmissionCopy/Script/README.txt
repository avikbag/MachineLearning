To run the script, simply use the following command, 
  
  ./main.py

All the source information for the computation of S-fold cross validation and closed form linear regression is avaliable in the SFoldCrossValid.py and CFLinearReg.py scripts respectively
